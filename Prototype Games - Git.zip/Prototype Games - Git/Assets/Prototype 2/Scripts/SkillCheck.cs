﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SkillCheck : MonoBehaviour
{
    public PlayerScript.PlayerID playerCheck;
    public float skillInterval;
    public bool isChecking;
}
