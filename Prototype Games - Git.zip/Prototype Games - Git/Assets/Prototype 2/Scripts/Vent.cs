﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Vent : MonoBehaviour
{
    public GameObject Icon;
    internal BoxCollider2D MyCollider;
}
